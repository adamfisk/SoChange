require 'test_helper'

class ChangemakersHelperTest < ActionView::TestCase
end
