require 'test_helper'

class MissionsHelperTest < ActionView::TestCase
end
