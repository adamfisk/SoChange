class ChangemakersController < ApplicationController
  def index
    
  end
end
