class Mission < ActiveRecord::Base
end
